Budget it backup, 2026-11-11T07:04:26.817Z
To restore: in the app, tap your picture, then People, backups and health, then Restore a backup. Or stop the server and run: node server.js restore THIS-FILE
secret.key unlocks the bank connections in db.json. Keep this zip somewhere private.
